import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { MapmodalPage } from './mapmodal';

@NgModule({
  declarations: [
    MapmodalPage,
  ],
  imports: [
    IonicPageModule.forChild(MapmodalPage),
  ],
})
export class MapmodalPageModule {}
